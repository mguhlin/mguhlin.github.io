#!/bin/sh
APP_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
exec "$APP_DIR/runtime/python/bin/python3" -I "$APP_DIR/app.py" "$@"
