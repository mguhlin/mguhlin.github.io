@echo off
"%~dp0runtime\python.exe" -I "%~dp0app.py" %*
if errorlevel 1 pause
